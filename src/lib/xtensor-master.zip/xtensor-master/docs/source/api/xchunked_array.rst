.. Copyright (c) 2016, Johan Mabille, Sylvaidan Corlay and Wolf Vollprecht

   Distributed under the terms of the BSD 3-Clause License.

   The full license is in the file LICENSE, distributed with this software.

xchunked_array
==============

.. cpp:namespace-push:: xt

.. doxygengroup:: xt_xchunked_array

.. cpp:namespace-pop::
